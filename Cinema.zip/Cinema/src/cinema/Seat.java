/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cinema;

/**
 *
 * @author nc
 */
public class Seat {
    
    private int id;
    private String no;
    private String type;
    private int price;
    private boolean selected;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public Seat(int id, String no, String type, int price, boolean selected) {
        this.id = id;
        this.no = no;
        this.type = type;
        this.price = price;
        this.selected = selected;
    }

    public Seat(String no, String type, int price, boolean selected) {
        this.no = no;
        this.type = type;
        this.price = price;
        this.selected = selected;
    }

    
    public Seat() {
    }

    
    
    
    
}
